﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmployeeManagement.Models
{
    public enum OperationType
    {
        Addition,
        Multiplication,
        Division,
        Subtraction
    }
}