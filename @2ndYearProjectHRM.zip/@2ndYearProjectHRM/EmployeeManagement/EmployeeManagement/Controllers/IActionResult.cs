﻿namespace EmployeeManagement.Controllers
{
    public interface IActionResult
    {
    }
}